import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import { ThemeProvider } from './context/ThemeContext.tsx';

// Ensure global fetch cannot crash if an injected library attempts to assign to it
try {
  let activeFetch = window.fetch;
  Object.defineProperty(window, 'fetch', {
    get: () => activeFetch,
    set: (fn) => { activeFetch = fn; },
    configurable: true,
    enumerable: true,
  });
} catch (_) {}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <ThemeProvider>
      <App />
    </ThemeProvider>
  </StrictMode>,
);
