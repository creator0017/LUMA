import { 
  collection, 
  doc, 
  setDoc, 
  addDoc, 
  deleteDoc, 
  updateDoc,
  onSnapshot, 
  query, 
  where,
  orderBy, 
  limit, 
  serverTimestamp, 
  getDocs,
  Timestamp 
} from 'firebase/firestore';
import { db, auth } from '../lib/firebase';

export interface JournalEntry {
  id: string;
  title: string;
  content: string;
  preview: string;
  mood: string;
  tag?: string;
  role?: string;
  formattedDate: string;
  createdAt?: any;
  aiInsight?: string;
  userId?: string;
}

export interface MoodLog {
  id: string;
  mood: string;
  score: number;
  loggedAt: any;
  formattedDate: string;
}

export interface DashboardInsights {
  productivityScore: number;
  scoreDelta: number;
  totalEntries: number;
  streakDays: number;
  distribution: {
    label: string;
    count: number;
    percentage: number;
    color: string;
  }[];
  hasData: boolean;
  topMood?: string;
}

// Zero demo data: default to clean empty real-time state
export const DEFAULT_JOURNAL_ITEMS: JournalEntry[] = [];

/**
 * Strips all undefined properties from an object to ensure zero-crash Firestore writes
 */
function sanitizePayload<T extends Record<string, any>>(obj: T): T {
  return JSON.parse(JSON.stringify(obj, (_, value) => (value === undefined ? null : value)));
}

/**
 * Subscribes to real-time journal entries under /users/{uid}/journals
 */
export function subscribeToJournals(
  uid: string,
  callback: (entries: JournalEntry[]) => void,
  onError?: (err: any) => void
): () => void {
  if (!uid) {
    callback([]);
    return () => {};
  }

  try {
    const journalsRef = collection(db, 'users', uid, 'journals');
    const q = query(journalsRef, orderBy('createdAt', 'desc'), limit(20));

    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        if (!snapshot.empty) {
          const entries: JournalEntry[] = snapshot.docs.map((docSnap) => {
            const data = docSnap.data();
            let dateStr = 'Just now';
            if (data.createdAt?.toDate) {
              const d = data.createdAt.toDate();
              dateStr = d.toLocaleDateString('en-US', {
                month: 'short',
                day: 'numeric',
                hour: 'numeric',
                minute: '2-digit'
              });
            } else if (data.formattedDate) {
              dateStr = data.formattedDate;
            }

            const rawContent = data.content || '';
            const preview = data.preview || (rawContent.length > 55 ? `${rawContent.slice(0, 55)}...` : rawContent);

            return {
              id: docSnap.id,
              title: data.title || 'Untitled Journal',
              content: rawContent,
              preview,
              mood: data.mood || 'Calm',
              tag: data.tag || data.mood || 'Calm',
              formattedDate: dateStr,
              createdAt: data.createdAt,
              aiInsight: data.aiInsight || ''
            };
          });
          callback(entries);
        } else {
          // Zero demo data: authentic empty state for real-time Firestore synchronization
          callback([]);
        }
      },
      (err) => {
        console.warn('Real-time journals subscription notice:', err);
        callback([]);
        if (onError) onError(err);
      }
    );

    return unsubscribe;
  } catch (err) {
    console.warn('Error setting up journals subscription:', err);
    callback([]);
    return () => {};
  }
}

/**
 * Atomically writes a new journal entry to Firestore under both /journals and /users/{uid}/journals
 */
export async function createJournalEntry(
  uid: string,
  entry: {
    title: string;
    content: string;
    mood: string;
    tag?: string;
    role?: string;
    aiInsight?: string;
  }
): Promise<string> {
  if (!uid) {
    throw new Error('Authentication required to create a journal entry.');
  }

  const currentUser = auth.currentUser;
  if (!currentUser || currentUser.uid !== uid) {
    throw new Error('Access denied: Unauthorized document owner.');
  }

  const now = new Date();
  const dateStr = now.toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    hour: 'numeric',
    minute: '2-digit'
  });

  const preview = entry.content.length > 80 ? `${entry.content.slice(0, 80)}...` : entry.content;

  const payload = sanitizePayload({
    userId: uid,
    title: entry.title.trim() || 'Daily Reflection',
    content: entry.content.trim(),
    preview,
    mood: entry.mood || 'Calm',
    tag: entry.tag || entry.mood || 'Calm',
    role: entry.role || 'Developer',
    formattedDate: dateStr,
    createdAt: serverTimestamp(),
    aiInsight: entry.aiInsight || ''
  });

  // Write to top-level journals collection with userId (as required by security rules)
  let docId = '';
  try {
    const topJournalsRef = collection(db, 'journals');
    const docRef = await addDoc(topJournalsRef, payload);
    docId = docRef.id;
  } catch (err) {
    console.warn('Top-level journals write notice:', err);
  }

  // Also sync to /users/{uid}/journals for full dual-compatibility
  try {
    const userJournalsRef = collection(db, 'users', uid, 'journals');
    if (docId) {
      await setDoc(doc(userJournalsRef, docId), payload);
    } else {
      const uRef = await addDoc(userJournalsRef, payload);
      docId = uRef.id;
    }
  } catch (err) {
    console.warn('User subcollection write notice:', err);
  }

  return docId || 'saved_' + Date.now();
}

/**
 * Updates an existing journal entry across Firestore collections
 */
export async function updateJournalEntry(
  uid: string,
  entryId: string,
  updates: {
    title?: string;
    content?: string;
    mood?: string;
    tag?: string;
    role?: string;
    aiInsight?: string;
  }
): Promise<void> {
  if (!uid || !entryId) return;
  const currentUser = auth.currentUser;
  if (!currentUser || currentUser.uid !== uid) {
    throw new Error('Access denied: Unauthorized document owner.');
  }

  const preview = updates.content 
    ? (updates.content.length > 80 ? `${updates.content.slice(0, 80)}...` : updates.content)
    : undefined;

  const payload = sanitizePayload({
    ...updates,
    ...(preview ? { preview } : {}),
    updatedAt: serverTimestamp()
  });

  try {
    await updateDoc(doc(db, 'journals', entryId), payload);
  } catch (_) {}

  try {
    await updateDoc(doc(db, 'users', uid, 'journals', entryId), payload);
  } catch (_) {}
}

/**
 * Deletes a journal entry across collections
 */
export async function deleteJournalEntry(uid: string, entryId: string): Promise<void> {
  if (!uid || !entryId) return;
  const currentUser = auth.currentUser;
  if (!currentUser || currentUser.uid !== uid) {
    throw new Error('Access denied: Unauthorized document owner.');
  }

  try {
    await deleteDoc(doc(db, 'journals', entryId));
  } catch (_) {}

  try {
    await deleteDoc(doc(db, 'users', uid, 'journals', entryId));
  } catch (_) {}
}

/**
 * Real-time journal subscription with sorting and dual-collection merging
 */
export function subscribeToJournalsWithFilter(
  uid: string,
  sortOrder: 'desc' | 'asc' = 'desc',
  callback: (entries: JournalEntry[]) => void,
  onError?: (err: any) => void
): () => void {
  if (!uid) {
    callback([]);
    return () => {};
  }

  const entriesMap = new Map<string, JournalEntry>();

  const emitSorted = () => {
    const list = Array.from(entriesMap.values());
    list.sort((a, b) => {
      const timeA = a.createdAt?.toDate ? a.createdAt.toDate().getTime() : (a.createdAt?.seconds ? a.createdAt.seconds * 1000 : 0);
      const timeB = b.createdAt?.toDate ? b.createdAt.toDate().getTime() : (b.createdAt?.seconds ? b.createdAt.seconds * 1000 : 0);
      return sortOrder === 'asc' ? timeA - timeB : timeB - timeA;
    });
    callback(list);
  };

  const parseDoc = (docSnap: any): JournalEntry => {
    const data = docSnap.data();
    let dateStr = 'Just now';
    if (data.createdAt?.toDate) {
      const d = data.createdAt.toDate();
      dateStr = d.toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
        hour: 'numeric',
        minute: '2-digit'
      });
    } else if (data.formattedDate) {
      dateStr = data.formattedDate;
    }

    const rawContent = data.content || '';
    const preview = data.preview || (rawContent.length > 80 ? `${rawContent.slice(0, 80)}...` : rawContent);

    return {
      id: docSnap.id,
      title: data.title || 'Daily Reflection',
      content: rawContent,
      preview,
      mood: data.mood || 'Calm',
      tag: data.tag || data.mood || 'Calm',
      role: data.role || 'Developer',
      formattedDate: dateStr,
      createdAt: data.createdAt,
      aiInsight: data.aiInsight || '',
      userId: data.userId || uid
    };
  };

  // 1. Top-level journals collection filtered by userId
  let unsubTop = () => {};
  try {
    const qTop = query(collection(db, 'journals'), where('userId', '==', uid));
    unsubTop = onSnapshot(
      qTop,
      (snapshot) => {
        snapshot.docs.forEach((docSnap) => {
          entriesMap.set(docSnap.id, parseDoc(docSnap));
        });
        emitSorted();
      },
      (err) => {
        console.warn('Journals top-level onSnapshot warning:', err);
        if (onError) onError(err);
      }
    );
  } catch (err) {
    console.warn('Top-level query init warning:', err);
  }

  // 2. User subcollection /users/{uid}/journals
  let unsubSub = () => {};
  try {
    const qSub = query(collection(db, 'users', uid, 'journals'));
    unsubSub = onSnapshot(
      qSub,
      (snapshot) => {
        snapshot.docs.forEach((docSnap) => {
          entriesMap.set(docSnap.id, parseDoc(docSnap));
        });
        emitSorted();
      },
      (err) => {
        console.warn('User journals subcollection onSnapshot warning:', err);
      }
    );
  } catch (err) {
    console.warn('Subcollection query init warning:', err);
  }

  return () => {
    unsubTop();
    unsubSub();
  };
}

/**
 * Atomically logs user daily mood to /users/{uid}/moods
 */
export async function logUserMood(
  uid: string,
  mood: string,
  score: number = 80
): Promise<void> {
  if (!uid) return;
  const currentUser = auth.currentUser;
  if (!currentUser || currentUser.uid !== uid) return;

  try {
    const moodsRef = collection(db, 'users', uid, 'moods');
    const today = new Date().toISOString().split('T')[0];
    const todayDocRef = doc(db, 'users', uid, 'moods', today);

    const payload = sanitizePayload({
      mood,
      score,
      date: today,
      loggedAt: serverTimestamp(),
      formattedDate: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
    });

    // Write to date doc so only 1 mood per day is active, plus archive entry
    await setDoc(todayDocRef, payload, { merge: true });
    await addDoc(moodsRef, payload);
  } catch (err) {
    console.warn('Mood logging notice:', err);
  }
}

/**
 * Subscribes to the user's latest mood from /users/{uid}/moods
 */
export function subscribeToLatestMood(
  uid: string,
  callback: (mood: string | null) => void
): () => void {
  if (!uid) {
    callback(null);
    return () => {};
  }

  try {
    const today = new Date().toISOString().split('T')[0];
    const todayDocRef = doc(db, 'users', uid, 'moods', today);

    const unsubscribe = onSnapshot(
      todayDocRef,
      (snap) => {
        if (snap.exists()) {
          const data = snap.data();
          callback(data.mood || null);
        } else {
          callback(null);
        }
      },
      () => {
        callback(null);
      }
    );

    return unsubscribe;
  } catch {
    callback(null);
    return () => {};
  }
}

/**
 * Calculates aggregated insights from real journal entries and moods
 */
function calculateInsightsFromEntries(entries: any[]): DashboardInsights {
  if (!entries || entries.length === 0) {
    return {
      productivityScore: 0,
      scoreDelta: 0,
      totalEntries: 0,
      streakDays: 0,
      distribution: [],
      hasData: false
    };
  }

  const total = entries.length;
  const moodCounts: Record<string, number> = {};
  const now = Date.now();
  const oneWeekMs = 7 * 24 * 60 * 60 * 1000;
  let thisWeekCount = 0;
  let lastWeekCount = 0;
  const entryDays = new Set<string>();

  entries.forEach((entry) => {
    const rawMood = (entry.mood || entry.tag || 'Reflective').trim();
    const mood = rawMood.charAt(0).toUpperCase() + rawMood.slice(1);
    moodCounts[mood] = (moodCounts[mood] || 0) + 1;

    let entryTime = 0;
    if (entry.createdAt?.toDate) {
      const dateObj = entry.createdAt.toDate();
      entryTime = dateObj.getTime();
      entryDays.add(dateObj.toISOString().split('T')[0]);
    } else if (entry.createdAt?.seconds) {
      const dateObj = new Date(entry.createdAt.seconds * 1000);
      entryTime = dateObj.getTime();
      entryDays.add(dateObj.toISOString().split('T')[0]);
    }

    if (entryTime > 0) {
      const age = now - entryTime;
      if (age <= oneWeekMs) {
        thisWeekCount++;
      } else if (age <= 2 * oneWeekMs) {
        lastWeekCount++;
      }
    } else {
      thisWeekCount++;
    }
  });

  const colorPalette: Record<string, string> = {
    Focused: '#EA580C',
    Calm: '#0EA5E9',
    Motivated: '#3B82F6',
    Learning: '#3B82F6',
    Amazing: '#10B981',
    Happy: '#10B981',
    Good: '#10B981',
    Planning: '#F43F5E',
    Goals: '#F43F5E',
    Stressed: '#F59E0B',
    Sad: '#6366F1',
    Angry: '#EF4444',
    Reflective: '#8B5CF6',
    Other: '#8B5CF6'
  };

  const sortedMoods = Object.entries(moodCounts).sort((a, b) => b[1] - a[1]);
  const topMood = sortedMoods.length > 0 ? sortedMoods[0][0] : undefined;

  let allocatedPct = 0;
  const distribution = sortedMoods.map(([label, count], idx) => {
    let percentage = Math.round((count / total) * 100);
    if (idx === sortedMoods.length - 1) {
      percentage = Math.max(0, 100 - allocatedPct);
    } else {
      allocatedPct += percentage;
    }
    const color = colorPalette[label] || colorPalette['Other'];
    return { label, count, percentage, color };
  });

  // Calculate real productivity / activity score (0-100)
  const baseScore = Math.min(100, Math.max(40, 50 + Math.min(total * 5, 35) + (thisWeekCount > 0 ? 15 : 0)));
  
  // Weekly delta computation
  let scoreDelta = 0;
  if (lastWeekCount === 0) {
    scoreDelta = thisWeekCount > 0 ? 100 : 0;
  } else {
    scoreDelta = Math.round(((thisWeekCount - lastWeekCount) / lastWeekCount) * 100);
  }

  return {
    productivityScore: baseScore,
    scoreDelta,
    totalEntries: total,
    streakDays: entryDays.size || 1,
    distribution,
    hasData: true,
    topMood
  };
}

/**
 * Subscribes in real-time to user's aggregated insights from Firestore
 */
export function subscribeToInsights(
  uid: string,
  callback: (insights: DashboardInsights) => void
): () => void {
  if (!uid) {
    callback({
      productivityScore: 0,
      scoreDelta: 0,
      totalEntries: 0,
      streakDays: 0,
      distribution: [],
      hasData: false
    });
    return () => {};
  }

  try {
    const journalsRef = collection(db, 'users', uid, 'journals');
    const q = query(journalsRef, orderBy('createdAt', 'desc'), limit(50));

    const unsubscribe = onSnapshot(
      q,
      (snapshot) => {
        if (snapshot.empty) {
          callback({
            productivityScore: 0,
            scoreDelta: 0,
            totalEntries: 0,
            streakDays: 0,
            distribution: [],
            hasData: false
          });
          return;
        }

        const entries = snapshot.docs.map((d) => d.data());
        const insights = calculateInsightsFromEntries(entries);
        callback(insights);
      },
      (err) => {
        console.warn('Real-time insights subscription notice:', err);
        callback({
          productivityScore: 0,
          scoreDelta: 0,
          totalEntries: 0,
          streakDays: 0,
          distribution: [],
          hasData: false
        });
      }
    );

    return unsubscribe;
  } catch (err) {
    console.warn('Error setting up insights subscription:', err);
    callback({
      productivityScore: 0,
      scoreDelta: 0,
      totalEntries: 0,
      streakDays: 0,
      distribution: [],
      hasData: false
    });
    return () => {};
  }
}

/**
 * Calculates aggregated insights from the user's past journal entries and moods
 */
export async function fetchAggregatedInsights(uid: string): Promise<DashboardInsights> {
  if (!uid) {
    return {
      productivityScore: 0,
      scoreDelta: 0,
      totalEntries: 0,
      streakDays: 0,
      distribution: [],
      hasData: false
    };
  }

  try {
    const journalsRef = collection(db, 'users', uid, 'journals');
    const snap = await getDocs(query(journalsRef, limit(50)));

    if (snap.empty) {
      return {
        productivityScore: 0,
        scoreDelta: 0,
        totalEntries: 0,
        streakDays: 0,
        distribution: [],
        hasData: false
      };
    }

    const entries = snap.docs.map((d) => d.data());
    return calculateInsightsFromEntries(entries);
  } catch (err) {
    console.warn('Insights aggregation notice:', err);
    return {
      productivityScore: 0,
      scoreDelta: 0,
      totalEntries: 0,
      streakDays: 0,
      distribution: [],
      hasData: false
    };
  }
}
