import { useState, useEffect } from 'react';
import { onAuthStateChanged, User } from 'firebase/auth';
import { auth } from './firebase';

export interface AuthState {
  user: User | null;
  loading: boolean;
  isAuthenticated: boolean;
}

export function useAuth(): AuthState {
  const [user, setUser] = useState<any | null>(() => {
    if (auth.currentUser) return auth.currentUser;
    try {
      const active = localStorage.getItem('luma_active_user');
      if (active) return JSON.parse(active);
    } catch (_) {}
    return null;
  });
  const [loading, setLoading] = useState<boolean>(!auth.currentUser && !localStorage.getItem('luma_active_user'));

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (firebaseUser) => {
      if (firebaseUser) {
        setUser(firebaseUser);
      } else {
        try {
          const active = localStorage.getItem('luma_active_user');
          if (active) {
            setUser(JSON.parse(active));
          } else {
            setUser(null);
          }
        } catch (_) {
          setUser(null);
        }
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  return {
    user,
    loading,
    isAuthenticated: !!user
  };
}
