import React, { useState } from 'react';
import { useTheme, ThemeMode } from '../context/ThemeContext';
import { Sun, Moon, Monitor, Check, User, Mail, Shield, Sparkles, Database, RefreshCw } from 'lucide-react';
import { auth, db, doc, updateDoc, setDoc } from '../lib/firebase';

interface SettingsViewProps {
  user?: any;
  showToast: (msg: string) => void;
}

export const SettingsView: React.FC<SettingsViewProps> = ({ user, showToast }) => {
  const { theme, setTheme, colorThemeConfig, setColorTheme } = useTheme();
  const [saving, setSaving] = useState(false);

  const handleThemeChange = async (newTheme: ThemeMode) => {
    setTheme(newTheme);
    if (newTheme === 'dark') {
      setColorTheme('dark');
    } else if (newTheme === 'light') {
      setColorTheme('warm');
    }
    showToast(`Appearance updated to: ${newTheme.toUpperCase()}`);

    // Persist to Firestore
    const currentUser = auth.currentUser || user;
    if (currentUser?.uid) {
      setSaving(true);
      try {
        const userRef = doc(db, 'users', currentUser.uid);
        await updateDoc(userRef, {
          'preferences.theme': newTheme,
          'preferences.colorTheme': newTheme === 'dark' ? 'dark' : 'warm'
        });
      } catch (err) {
        try {
          const userRef = doc(db, 'users', currentUser.uid);
          await setDoc(userRef, {
            preferences: {
              theme: newTheme,
              colorTheme: newTheme === 'dark' ? 'dark' : 'warm'
            }
          }, { merge: true });
        } catch (_) {}
      } finally {
        setSaving(false);
      }
    }
  };

  const displayName = user?.displayName || user?.email?.split('@')[0] || 'Luma User';
  const email = user?.email || 'user@luma.app';
  const uid = user?.uid || auth.currentUser?.uid || 'local-session-user';

  return (
    <div className="max-w-4xl mx-auto p-4 sm:p-6 space-y-6 animate-fadeIn">
      {/* Header */}
      <div className="flex items-center justify-between border-b pb-4" style={{ borderColor: colorThemeConfig.border }}>
        <div>
          <h1 className="text-xl sm:text-2xl font-serif-luma font-bold tracking-tight" style={{ color: colorThemeConfig.textPrimary }}>
            Settings &amp; Preferences
          </h1>
          <p className="text-xs sm:text-sm mt-0.5" style={{ color: colorThemeConfig.textSecondary }}>
            Manage your LUMA workspace appearance, sync preferences, and account settings.
          </p>
        </div>
        {saving && (
          <div className="flex items-center gap-1.5 text-xs text-orange-600 bg-orange-50 dark:bg-orange-950/50 px-3 py-1 rounded-full border border-orange-200 dark:border-orange-900">
            <RefreshCw className="w-3 h-3 animate-spin" />
            <span>Syncing...</span>
          </div>
        )}
      </div>

      {/* Appearance Section */}
      <div 
        className="rounded-3xl p-5 sm:p-6 border shadow-xs transition-colors duration-300"
        style={{
          backgroundColor: colorThemeConfig.bgSurface,
          borderColor: colorThemeConfig.border
        }}
      >
        <div className="flex items-center gap-2 mb-4">
          <Sparkles className="w-4 h-4 text-[#FD6B31]" />
          <h2 className="text-sm sm:text-base font-bold tracking-tight" style={{ color: colorThemeConfig.textPrimary }}>
            Appearance Theme (Image 1 &amp; Image 3 Source of Truth)
          </h2>
        </div>
        <p className="text-xs mb-5" style={{ color: colorThemeConfig.textSecondary }}>
          Choose your visual experience. Switching applies immediately across all pages, modals, and charts with a smooth transition.
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          {/* Light Theme Card (Image 1) */}
          <button
            type="button"
            onClick={() => handleThemeChange('light')}
            className={`text-left p-4 rounded-2xl border-2 transition-all cursor-pointer relative flex flex-col justify-between ${
              theme === 'light' 
                ? 'border-[#FD6B31] shadow-md bg-[#FAF7F2]' 
                : 'border-neutral-200 dark:border-neutral-800 hover:border-neutral-300 bg-white dark:bg-neutral-900'
            }`}
          >
            {theme === 'light' && (
              <div className="absolute top-3 right-3 w-5 h-5 rounded-full bg-[#FD6B31] text-white flex items-center justify-center shadow-xs">
                <Check className="w-3 h-3" />
              </div>
            )}
            <div>
              <div className="w-8 h-8 rounded-xl bg-orange-100 flex items-center justify-center text-[#FD6B31] mb-3">
                <Sun className="w-4 h-4" />
              </div>
              <h3 className="text-xs font-bold text-neutral-900">Light (Image 1)</h3>
              <p className="text-[11px] text-neutral-500 mt-1">
                Warm ivory background, soft cream surfaces, peach/orange ambient gradients &amp; elegant serif typography.
              </p>
            </div>
            <div className="mt-4 pt-3 border-t border-neutral-200 flex items-center gap-2">
              <span className="w-3 h-3 rounded-full bg-[#FD6B31]" />
              <span className="w-3 h-3 rounded-full bg-[#F9F9F9] border border-neutral-300" />
              <span className="text-[10px] font-semibold text-neutral-600">Warm Sand &amp; Ivory</span>
            </div>
          </button>

          {/* System Theme Card */}
          <button
            type="button"
            onClick={() => handleThemeChange('system')}
            className={`text-left p-4 rounded-2xl border-2 transition-all cursor-pointer relative flex flex-col justify-between ${
              theme === 'system' 
                ? 'border-[#FD6B31] shadow-md bg-neutral-50 dark:bg-neutral-800' 
                : 'border-neutral-200 dark:border-neutral-800 hover:border-neutral-300 bg-white dark:bg-neutral-900'
            }`}
          >
            {theme === 'system' && (
              <div className="absolute top-3 right-3 w-5 h-5 rounded-full bg-[#FD6B31] text-white flex items-center justify-center shadow-xs">
                <Check className="w-3 h-3" />
              </div>
            )}
            <div>
              <div className="w-8 h-8 rounded-xl bg-blue-100 dark:bg-blue-950 flex items-center justify-center text-blue-600 dark:text-blue-400 mb-3">
                <Monitor className="w-4 h-4" />
              </div>
              <h3 className="text-xs font-bold" style={{ color: colorThemeConfig.textPrimary }}>System Preference</h3>
              <p className="text-[11px]" style={{ color: colorThemeConfig.textSecondary }}>
                Automatically matches your operating system&apos;s light or dark mode settings in real-time.
              </p>
            </div>
            <div className="mt-4 pt-3 border-t border-neutral-200 dark:border-neutral-800 flex items-center gap-2">
              <span className="w-3 h-3 rounded-full bg-blue-500" />
              <span className="text-[10px] font-semibold text-neutral-600 dark:text-neutral-400">Auto OS Detect</span>
            </div>
          </button>

          {/* Dark Theme Card (Image 3) */}
          <button
            type="button"
            onClick={() => handleThemeChange('dark')}
            className={`text-left p-4 rounded-2xl border-2 transition-all cursor-pointer relative flex flex-col justify-between ${
              theme === 'dark' 
                ? 'border-[#FF7A3D] shadow-md bg-[#18191B]' 
                : 'border-neutral-200 dark:border-neutral-800 hover:border-neutral-300 bg-white dark:bg-neutral-900'
            }`}
          >
            {theme === 'dark' && (
              <div className="absolute top-3 right-3 w-5 h-5 rounded-full bg-[#FF7A3D] text-white flex items-center justify-center shadow-xs">
                <Check className="w-3 h-3" />
              </div>
            )}
            <div>
              <div className="w-8 h-8 rounded-xl bg-neutral-800 flex items-center justify-center text-[#FF7A3D] mb-3">
                <Moon className="w-4 h-4" />
              </div>
              <h3 className="text-xs font-bold text-white">Dark (Image 3)</h3>
              <p className="text-[11px] text-neutral-400 mt-1">
                Deep obsidian charcoal background, layered dark surfaces, cinematic orange ambient glow &amp; white typography.
              </p>
            </div>
            <div className="mt-4 pt-3 border-t border-neutral-800 flex items-center gap-2">
              <span className="w-3 h-3 rounded-full bg-[#FF7A3D]" />
              <span className="w-3 h-3 rounded-full bg-[#0F1011] border border-neutral-700" />
              <span className="text-[10px] font-semibold text-neutral-300">Midnight Obsidian</span>
            </div>
          </button>
        </div>
      </div>

      {/* Account & Firestore Profile Sync Section */}
      <div 
        className="rounded-3xl p-5 sm:p-6 border shadow-xs transition-colors duration-300"
        style={{
          backgroundColor: colorThemeConfig.bgSurface,
          borderColor: colorThemeConfig.border
        }}
      >
        <div className="flex items-center gap-2 mb-4">
          <User className="w-4 h-4 text-[#FD6B31]" />
          <h2 className="text-sm sm:text-base font-bold tracking-tight" style={{ color: colorThemeConfig.textPrimary }}>
            Account Profile &amp; Cloud Sync
          </h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
          <div className="p-3.5 rounded-2xl bg-neutral-50 dark:bg-neutral-800/50 border border-neutral-200/80 dark:border-neutral-800 flex items-center gap-3">
            <User className="w-4 h-4 text-neutral-400 shrink-0" />
            <div className="min-w-0">
              <p className="text-[10px] text-neutral-400 font-medium">Display Name</p>
              <p className="font-bold truncate" style={{ color: colorThemeConfig.textPrimary }}>{displayName}</p>
            </div>
          </div>

          <div className="p-3.5 rounded-2xl bg-neutral-50 dark:bg-neutral-800/50 border border-neutral-200/80 dark:border-neutral-800 flex items-center gap-3">
            <Mail className="w-4 h-4 text-neutral-400 shrink-0" />
            <div className="min-w-0">
              <p className="text-[10px] text-neutral-400 font-medium">Email Address</p>
              <p className="font-bold truncate" style={{ color: colorThemeConfig.textPrimary }}>{email}</p>
            </div>
          </div>

          <div className="p-3.5 rounded-2xl bg-neutral-50 dark:bg-neutral-800/50 border border-neutral-200/80 dark:border-neutral-800 flex items-center gap-3">
            <Database className="w-4 h-4 text-neutral-400 shrink-0" />
            <div className="min-w-0">
              <p className="text-[10px] text-neutral-400 font-medium">Firestore Path</p>
              <p className="font-mono text-[11px] truncate" style={{ color: colorThemeConfig.textPrimary }}>/users/{uid}/profile/preferences/theme</p>
            </div>
          </div>

          <div className="p-3.5 rounded-2xl bg-neutral-50 dark:bg-neutral-800/50 border border-neutral-200/80 dark:border-neutral-800 flex items-center gap-3">
            <Shield className="w-4 h-4 text-neutral-400 shrink-0" />
            <div className="min-w-0">
              <p className="text-[10px] text-neutral-400 font-medium">Security &amp; Auth</p>
              <p className="font-bold truncate text-emerald-600 dark:text-emerald-400">Secured via Firebase Auth</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
