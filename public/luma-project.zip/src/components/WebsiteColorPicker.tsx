import React, { useState, useRef, useEffect } from 'react';
import { Palette, Check, ChevronDown } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useTheme, ColorTheme, COLOR_THEMES } from '../context/ThemeContext';

interface WebsiteColorPickerProps {
  onColorChangeNotice?: (message: string) => void;
}

export const WebsiteColorPicker: React.FC<WebsiteColorPickerProps> = ({ onColorChangeNotice }) => {
  const { colorTheme, colorThemeConfig, setColorTheme, cycleNextColorTheme } = useTheme();
  const [isOpen, setIsOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  // Close dropdown on outside click
  useEffect(() => {
    const handleOutsideClick = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setIsOpen(false);
    };

    if (isOpen) {
      document.addEventListener('mousedown', handleOutsideClick);
      document.addEventListener('keydown', handleEscape);
    }
    return () => {
      document.removeEventListener('mousedown', handleOutsideClick);
      document.removeEventListener('keydown', handleEscape);
    };
  }, [isOpen]);

  const handleSelectColor = (themeId: ColorTheme) => {
    setColorTheme(themeId);
    setIsOpen(false);
    const target = COLOR_THEMES[themeId];
    if (onColorChangeNotice) {
      onColorChangeNotice(`Website color changed to ${target.name}`);
    }
  };

  const handleQuickCycle = (e: React.MouseEvent) => {
    e.stopPropagation();
    const nextTheme = cycleNextColorTheme();
    if (onColorChangeNotice) {
      onColorChangeNotice(`Website color changed to ${nextTheme.name}`);
    }
  };

  return (
    <div ref={containerRef} className="relative inline-block text-left">
      {/* Website Color Switcher Button */}
      <div className="flex items-center rounded-full bg-white/80 dark:bg-neutral-800/80 border border-neutral-200/90 dark:border-neutral-700/80 shadow-2xs hover:border-neutral-300 transition-all">
        <button
          id="website-color-cycle-btn"
          type="button"
          onClick={handleQuickCycle}
          title={`Website Color: ${colorThemeConfig.name}. Click to cycle color`}
          className="flex items-center gap-1.5 py-1.5 pl-2.5 pr-1.5 text-xs font-semibold text-neutral-700 dark:text-neutral-200 hover:text-neutral-900 transition-colors cursor-pointer select-none"
        >
          <div
            className="w-4 h-4 rounded-full flex items-center justify-center text-white shadow-2xs transition-transform hover:scale-110"
            style={{ backgroundColor: colorThemeConfig.primary }}
          >
            <Palette className="w-2.5 h-2.5" />
          </div>
          <span className="hidden sm:inline text-[11px] font-medium tracking-tight">
            {colorThemeConfig.name}
          </span>
        </button>

        <button
          id="website-color-dropdown-toggle"
          type="button"
          onClick={() => setIsOpen(!isOpen)}
          title="Choose Website Color Theme"
          aria-expanded={isOpen}
          className="py-1.5 pr-2 pl-0.5 text-neutral-400 hover:text-neutral-700 dark:hover:text-neutral-200 transition-colors cursor-pointer"
        >
          <ChevronDown className={`w-3.5 h-3.5 transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`} />
        </button>
      </div>

      {/* Dropdown Menu */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 6, scale: 0.96 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 4, scale: 0.96 }}
            transition={{ duration: 0.15 }}
            className="absolute right-0 mt-2 w-56 rounded-2xl bg-white dark:bg-neutral-900 border border-neutral-200/90 dark:border-neutral-700 shadow-xl py-2 z-50 overflow-hidden"
          >
            <div className="px-3 py-1.5 border-b border-neutral-100 dark:border-neutral-800 flex items-center justify-between">
              <span className="text-[11px] font-bold text-neutral-500 uppercase tracking-wider">
                Website Colors
              </span>
              <span className="text-[10px] text-neutral-400">
                Click to apply
              </span>
            </div>

            <div className="py-1 space-y-0.5">
              {(Object.keys(COLOR_THEMES) as ColorTheme[]).map((themeKey) => {
                const themeItem = COLOR_THEMES[themeKey];
                const isSelected = colorTheme === themeKey;

                return (
                  <button
                    key={themeKey}
                    id={`website-color-option-${themeKey}`}
                    type="button"
                    onClick={() => handleSelectColor(themeKey)}
                    className={`w-full flex items-center justify-between px-3 py-2 text-left text-xs transition-colors cursor-pointer ${
                      isSelected
                        ? 'bg-neutral-100 dark:bg-neutral-800 text-neutral-900 dark:text-white font-semibold'
                        : 'text-neutral-600 dark:text-neutral-300 hover:bg-neutral-50 dark:hover:bg-neutral-800/60'
                    }`}
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <span
                        className="w-4 h-4 rounded-full shrink-0 border border-black/10 dark:border-white/20 shadow-2xs"
                        style={{ backgroundColor: themeItem.primary }}
                      />
                      <div className="truncate">
                        <div className="text-xs font-medium leading-none">
                          {themeItem.name}
                        </div>
                        <div className="text-[10px] text-neutral-400 leading-tight mt-0.5">
                          {themeItem.label}
                        </div>
                      </div>
                    </div>

                    {isSelected && (
                      <Check className="w-3.5 h-3.5 text-neutral-900 dark:text-white shrink-0 ml-2" />
                    )}
                  </button>
                );
              })}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
