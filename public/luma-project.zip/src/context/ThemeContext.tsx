import React, { createContext, useContext, useEffect, useState } from 'react';
import { auth, db, doc, getDoc, setDoc, updateDoc } from '../lib/firebase';

export type ThemeMode = 'light' | 'dark' | 'system';
export type ColorTheme = 'warm' | 'dark' | 'emerald' | 'indigo' | 'rose' | 'ocean';

export interface ColorThemeConfig {
  id: ColorTheme;
  name: string;
  label: string;
  description: string;
  bgMain: string;
  bgSurface: string;
  bgHeader: string;
  bgSidebar: string;
  bgCard: string;
  primary: string;
  primaryHover: string;
  textPrimary: string;
  textSecondary: string;
  border: string;
  accentBg: string;
  accentText: string;
  swatchColor: string;
  ringColor: string;
  isDark: boolean;
}

export const COLOR_THEMES: Record<ColorTheme, ColorThemeConfig> = {
  warm: {
    id: 'warm',
    name: 'Warm Sand',
    label: 'Classic Luma',
    description: 'Warm ivory background, soft cream surfaces and peach/orange accents',
    bgMain: '#F9F9F9',
    bgSurface: '#FFFFFF',
    bgHeader: '#F9F9F9',
    bgSidebar: '#FFFFFF',
    bgCard: '#FFFFFF',
    primary: '#000000',
    primaryHover: '#1A1C1C',
    textPrimary: '#1A1C1C',
    textSecondary: '#4C4546',
    border: '#CFC4C5',
    accentBg: '#FFF2E8',
    accentText: '#FD6B31',
    swatchColor: '#FD6B31',
    ringColor: '#FED7AA',
    isDark: false
  },
  dark: {
    id: 'dark',
    name: 'Midnight Obsidian',
    label: 'Obsidian Dark',
    description: 'Deep charcoal background, layered dark surfaces and orange glow',
    bgMain: '#0B0B0B',
    bgSurface: '#111111',
    bgHeader: '#0B0B0B',
    bgSidebar: '#111111',
    bgCard: '#161616',
    primary: '#FD6B31',
    primaryHover: '#FF7A3D',
    textPrimary: '#F5F5F5',
    textSecondary: '#B8B8B8',
    border: 'rgba(255, 255, 255, 0.10)',
    accentBg: 'rgba(253, 107, 49, 0.15)',
    accentText: '#FD6B31',
    swatchColor: '#111111',
    ringColor: '#FD6B31',
    isDark: true
  },
  emerald: {
    id: 'emerald',
    name: 'Emerald Zen',
    label: 'Sage Forest',
    description: 'Calming sage green and herbal mint accents',
    bgMain: '#F2F7F4',
    bgSurface: '#FFFFFF',
    bgHeader: '#F2F7F4',
    bgSidebar: '#F2F7F4',
    bgCard: '#FFFFFF',
    primary: '#059669',
    primaryHover: '#047857',
    textPrimary: '#132A1C',
    textSecondary: '#476A57',
    border: '#CFE2D6',
    accentBg: '#E6F4ED',
    accentText: '#059669',
    swatchColor: '#10B981',
    ringColor: '#A7F3D0',
    isDark: false
  },
  indigo: {
    id: 'indigo',
    name: 'Royal Violet',
    label: 'Lavender Bloom',
    description: 'Deep royal violet and misty lavender focus',
    bgMain: '#F4F4FA',
    bgSurface: '#FFFFFF',
    bgHeader: '#F4F4FA',
    bgSidebar: '#F4F4FA',
    bgCard: '#FFFFFF',
    primary: '#6366F1',
    primaryHover: '#4F46E5',
    textPrimary: '#1B1742',
    textSecondary: '#5B638A',
    border: '#DDDDF5',
    accentBg: '#EEF0FF',
    accentText: '#4F46E5',
    swatchColor: '#6366F1',
    ringColor: '#C7D2FE',
    isDark: false
  },
  rose: {
    id: 'rose',
    name: 'Sunset Rose',
    label: 'Blush Coral',
    description: 'Gentle blush rose with warm coral accents',
    bgMain: '#FAF2F4',
    bgSurface: '#FFFFFF',
    bgHeader: '#FAF2F4',
    bgSidebar: '#FAF2F4',
    bgCard: '#FFFFFF',
    primary: '#E11D48',
    primaryHover: '#BE123C',
    textPrimary: '#2B1318',
    textSecondary: '#7C4A55',
    border: '#F2D5DC',
    accentBg: '#FFEBF0',
    accentText: '#E11D48',
    swatchColor: '#F43F5E',
    ringColor: '#FECDD3',
    isDark: false
  },
  ocean: {
    id: 'ocean',
    name: 'Nordic Ocean',
    label: 'Serene Azure',
    description: 'Crisp fjord blue with crystalline clarity',
    bgMain: '#F0F6FA',
    bgSurface: '#FFFFFF',
    bgHeader: '#F0F6FA',
    bgSidebar: '#F0F6FA',
    bgCard: '#FFFFFF',
    primary: '#0284C7',
    primaryHover: '#0369A1',
    textPrimary: '#0C2233',
    textSecondary: '#4F6F8A',
    border: '#D1E2EE',
    accentBg: '#E4F2FA',
    accentText: '#0284C7',
    swatchColor: '#0EA5E9',
    ringColor: '#BAE6FD',
    isDark: false
  }
};

const COLOR_ORDER: ColorTheme[] = ['warm', 'dark', 'emerald', 'indigo', 'rose', 'ocean'];

export interface ThemeContextType {
  theme: ThemeMode;
  resolvedTheme: 'light' | 'dark';
  darkMode: boolean;
  toggleDarkMode: () => void;
  setTheme: (theme: ThemeMode) => void;
  colorTheme: ColorTheme;
  colorThemeConfig: ColorThemeConfig;
  setColorTheme: (color: ColorTheme) => void;
  cycleNextColorTheme: () => ColorThemeConfig;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

export const ThemeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [theme, setThemeState] = useState<ThemeMode>(() => {
    try {
      const saved = localStorage.getItem('luma-theme') as ThemeMode;
      if (saved === 'light' || saved === 'dark' || saved === 'system') {
        return saved;
      }
    } catch (_) {}
    return 'light';
  });

  const [colorTheme, setColorThemeState] = useState<ColorTheme>(() => {
    try {
      const savedColor = localStorage.getItem('luma-color-theme') as ColorTheme;
      if (savedColor && COLOR_THEMES[savedColor]) {
        return savedColor;
      }
    } catch (_) {}
    return 'warm';
  });

  const [resolvedTheme, setResolvedTheme] = useState<'light' | 'dark'>('light');

  // Handle theme mode (light, dark, system)
  useEffect(() => {
    if (theme === 'system') {
      const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
      const applySystem = (matches: boolean) => {
        setColorThemeState(matches ? 'dark' : 'warm');
      };
      applySystem(mediaQuery.matches);
      const listener = (e: MediaQueryListEvent) => applySystem(e.matches);
      mediaQuery.addEventListener('change', listener);
      return () => mediaQuery.removeEventListener('change', listener);
    } else if (theme === 'dark') {
      setColorThemeState('dark');
    } else if (theme === 'light') {
      setColorThemeState('warm');
    }
  }, [theme]);

  // Apply color theme and CSS custom properties
  useEffect(() => {
    const config = COLOR_THEMES[colorTheme] || COLOR_THEMES.warm;
    const root = document.documentElement;

    root.setAttribute('data-color-theme', colorTheme);
    root.setAttribute('data-theme', config.isDark ? 'dark' : 'light');

    if (config.isDark) {
      root.classList.add('dark');
      setResolvedTheme('dark');
    } else {
      root.classList.remove('dark');
      setResolvedTheme('light');
    }

    // Synchronize CSS custom properties
    root.style.setProperty('--bg-main', config.bgMain);
    root.style.setProperty('--bg-surface', config.bgSurface);
    root.style.setProperty('--text-primary', config.textPrimary);
    root.style.setProperty('--text-secondary', config.textSecondary);
    root.style.setProperty('--border-color', config.border);
    root.style.setProperty('--primary-orange', config.primary);
    root.style.setProperty('--primary-orange-hover', config.primaryHover);
    document.body.style.backgroundColor = config.bgMain;
    document.body.style.color = config.textPrimary;
  }, [colorTheme]);

  // Sync preference with Firebase user document if authenticated
  useEffect(() => {
    const user = auth.currentUser;
    if (!user) return;

    const fetchUserPreferences = async () => {
      try {
        const userDocRef = doc(db, 'users', user.uid);
        const snap = await getDoc(userDocRef);
        if (snap.exists()) {
          const data = snap.data();
          if (data?.preferences?.theme) {
            const remoteTheme = data.preferences.theme as ThemeMode;
            if (remoteTheme === 'light' || remoteTheme === 'dark' || remoteTheme === 'system') {
              setThemeState(remoteTheme);
              localStorage.setItem('luma-theme', remoteTheme);
              if (remoteTheme === 'dark') setColorThemeState('dark');
              else if (remoteTheme === 'light') setColorThemeState('warm');
            }
          } else if (data?.preferences?.colorTheme && COLOR_THEMES[data.preferences.colorTheme as ColorTheme]) {
            const remoteColor = data.preferences.colorTheme as ColorTheme;
            setColorThemeState(remoteColor);
            localStorage.setItem('luma-color-theme', remoteColor);
          }
        }
      } catch (err) {
        console.warn('Could not load preferences from Firebase:', err);
      }
    };

    fetchUserPreferences();
  }, [auth.currentUser?.uid]);

  const setTheme = (newTheme: ThemeMode) => {
    setThemeState(newTheme);
    try {
      localStorage.setItem('luma-theme', newTheme);
    } catch (_) {}

    if (newTheme === 'dark') {
      setColorThemeState('dark');
      try {
        localStorage.setItem('luma-color-theme', 'dark');
      } catch (_) {}
    } else if (newTheme === 'light') {
      setColorThemeState('warm');
      try {
        localStorage.setItem('luma-color-theme', 'warm');
      } catch (_) {}
    } else if (newTheme === 'system') {
      const isDarkOS = window.matchMedia('(prefers-color-scheme: dark)').matches;
      setColorThemeState(isDarkOS ? 'dark' : 'warm');
    }

    // Persist theme preference to Firestore non-blockingly
    const user = auth.currentUser;
    if (user) {
      const userDocRef = doc(db, 'users', user.uid);
      updateDoc(userDocRef, {
        'preferences.theme': newTheme,
        'preferences.colorTheme': newTheme === 'dark' ? 'dark' : (newTheme === 'light' ? 'warm' : (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'warm'))
      }).catch(async () => {
        try {
          await setDoc(userDocRef, {
            preferences: {
              theme: newTheme,
              colorTheme: newTheme === 'dark' ? 'dark' : 'warm'
            }
          }, { merge: true });
        } catch (_) {}
      });
    }
  };

  const setColorTheme = (newColor: ColorTheme) => {
    if (!COLOR_THEMES[newColor]) return;
    setColorThemeState(newColor);
    const isNowDark = COLOR_THEMES[newColor].isDark;
    setThemeState(isNowDark ? 'dark' : 'light');
    setResolvedTheme(isNowDark ? 'dark' : 'light');
    try {
      localStorage.setItem('luma-color-theme', newColor);
      localStorage.setItem('luma-theme', isNowDark ? 'dark' : 'light');
    } catch (_) {}

    // Persist to Firebase non-blockingly
    const user = auth.currentUser;
    if (user) {
      const userDocRef = doc(db, 'users', user.uid);
      updateDoc(userDocRef, {
        'preferences.colorTheme': newColor,
        'preferences.theme': isNowDark ? 'dark' : 'light'
      }).catch(async () => {
        try {
          await setDoc(userDocRef, { 
            preferences: { 
              colorTheme: newColor,
              theme: isNowDark ? 'dark' : 'light'
            } 
          }, { merge: true });
        } catch (_) {}
      });
    }
  };

  const cycleNextColorTheme = (): ColorThemeConfig => {
    const currentIndex = COLOR_ORDER.indexOf(colorTheme);
    const nextIndex = (currentIndex + 1) % COLOR_ORDER.length;
    const nextColor = COLOR_ORDER[nextIndex];
    setColorTheme(nextColor);
    return COLOR_THEMES[nextColor];
  };

  const colorThemeConfig = COLOR_THEMES[colorTheme] || COLOR_THEMES.warm;
  const darkMode = resolvedTheme === 'dark' || colorThemeConfig.isDark;
  const toggleDarkMode = () => {
    const next = darkMode ? 'light' : 'dark';
    setTheme(next);
  };

  return (
    <ThemeContext.Provider value={{
      theme,
      resolvedTheme,
      darkMode,
      toggleDarkMode,
      setTheme,
      colorTheme,
      colorThemeConfig,
      setColorTheme,
      cycleNextColorTheme
    }}>
      {children}
    </ThemeContext.Provider>
  );
};

export const useTheme = (): ThemeContextType => {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return context;
};
